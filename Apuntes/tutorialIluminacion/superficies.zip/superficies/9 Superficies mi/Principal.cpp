#include <windows.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include "glut.h"


#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glut32.lib")
#pragma comment(lib, "glu32.lib")

GLfloat angulo=0;
const GLfloat plasticoNegroAmb[4] = {0.0f,0.0f,0.0f,1.0f};
const GLfloat plasticoNegroDif[4] = {0.01f,0.01f,0.01f,1.0f};
const GLfloat plasticoNegroSpe[4] = {0.5f,0.5f,0.5f,1.0f};
GLfloat plasticoNegroShi = 32.0f;

const GLfloat oroAmb[4] = {0.24725f,0.2245f,0.0645f,1.0f};
const GLfloat oroDif[4] = {0.34615f,0.3143f,0.0903f,1.0f};
const GLfloat oroSpe[4] = {0.797357f,0.723991f,0.208006f,1.0f};
GLfloat oroShi = 128.0f;

const GLfloat esmeraldaAmb[4] = {0.0215f,0.1745f,0.0215f,0.55f};
const GLfloat esmeraldaDif[4] = {0.07568f,0.61424f,0.07568f,0.55f};
const GLfloat esmeraldaSpe[4] = {0.633f,0.727811f,0.633f,0.55};
GLfloat esmeraldaShi = 76.8f;

const GLfloat cromoAmb[4] = {0.25f,0.25f,0.25f,1.0f};
const GLfloat cromoDif[4] = {0.4f,0.4f,0.4f,1.0f};
const GLfloat cromoSpe[4] = {0.774597f,0.774597f,0.774597f,1.0f};
GLfloat cromoShi = 76.8f;

const GLfloat totalAmb[4] = {1.0f,1.0f,1.0f,1.0f};
const GLfloat totalDif[4] = {1.0f,1.0f,1.0f,1.0f};
const GLfloat totalSpe[4] = {1.0f,1.0f,1.0f,1.0f};
GLfloat totalShi = 128.0f;

const GLfloat nadaAmb[4] = {0.0f,0.0f,0.0f,1.0f};
const GLfloat nadaDif[4] = {0.0f,0.0f,0.0f,1.0f};
const GLfloat nadaSpe[4] = {0.0f,0.0f,0.0f,1.0f};
GLfloat nadaShi = 1.0f;

const GLfloat difusionAmb[4] = {0.0f,0.0f,0.0f,1.0f};
const GLfloat difusionDif[4] = {1.0f,1.0f,1.0f,1.0f};
const GLfloat difusionSpe[4] = {0.0f,0.0f,0.0f,1.0f};
GLfloat difusionShi = 1.0f;

const GLfloat ambienteAmb[4] = {1.0f,1.0f,1.0f,1.0f};
const GLfloat ambienteDif[4] = {0.0f,0.0f,0.0f,1.0f};
const GLfloat ambienteSpe[4] = {0.0f,0.0f,0.0f,1.0f};
GLfloat ambienteShi = 1.0f;

const GLfloat especularAmb[4] = {0.0f,0.0f,0.0f,1.0f};
const GLfloat especularDif[4] = {0.0f,0.0f,0.0f,1.0f};
const GLfloat especularSpe[4] = {1.0f,1.0f,1.0f,1.0f};
GLfloat especularShi = 40.0f;


void render(void)
{
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   glLoadIdentity();
   gluLookAt(0.0f,10.0f,40.0f,  0.0f,0.0f,0.0f,  0.0f,1.0f,0.0f);
 
   

   //Plastico Negro
   glMaterialfv(GL_FRONT, GL_AMBIENT, plasticoNegroAmb);
   glMaterialfv(GL_FRONT, GL_DIFFUSE, plasticoNegroDif);
   glMaterialfv(GL_FRONT, GL_SPECULAR, plasticoNegroSpe);
   glMaterialf(GL_FRONT, GL_SHININESS, plasticoNegroShi);
   
   glPushMatrix();
   glTranslatef(-10.0f,10.0f,0.0f);
   glRotatef(angulo,0.0f,1.0f,0.0f);
   glRotatef(15.0f,1.0f,0.0f,0.0f);
   glutSolidTeapot(3.0f);
   glPopMatrix();

   //Oro
   glMaterialfv(GL_FRONT, GL_AMBIENT, oroAmb);
   glMaterialfv(GL_FRONT, GL_DIFFUSE, oroDif);
   glMaterialfv(GL_FRONT, GL_SPECULAR, oroSpe);
   glMaterialf(GL_FRONT, GL_SHININESS, oroShi);
   
   glPushMatrix();
   glTranslatef(-10.0f,0.0f,0.0f);
   glRotatef(angulo,0.0f,1.0f,0.0f);
   glRotatef(15.0f,1.0f,0.0f,0.0f);
   glutSolidTeapot(3.0f);
   glPopMatrix();

   //Esmeralda
   glMaterialfv(GL_FRONT, GL_AMBIENT, esmeraldaAmb);
   glMaterialfv(GL_FRONT, GL_DIFFUSE, esmeraldaDif);
   glMaterialfv(GL_FRONT, GL_SPECULAR, esmeraldaSpe);
   glMaterialf(GL_FRONT, GL_SHININESS, esmeraldaShi);
   
   glPushMatrix();
   glTranslatef(-10.0f,-10.0f,0.0f);
   glRotatef(angulo,0.0f,1.0f,0.0f);
   glRotatef(15.0f,1.0f,0.0f,0.0f);
   glutSolidTeapot(3.0f);
   glPopMatrix();

   //Cromo
   glMaterialfv(GL_FRONT, GL_AMBIENT, cromoAmb);
   glMaterialfv(GL_FRONT, GL_DIFFUSE, cromoDif);
   glMaterialfv(GL_FRONT, GL_SPECULAR, cromoSpe);
   glMaterialf(GL_FRONT, GL_SHININESS, cromoShi);
   
   glPushMatrix();
   glTranslatef(0.0f,10.0f,0.0f);
   glRotatef(angulo,0.0f,1.0f,0.0f);
   glRotatef(15.0f,1.0f,0.0f,0.0f);
   glutSolidTeapot(3.0f);
   glPopMatrix();

   //Total
   glMaterialfv(GL_FRONT, GL_AMBIENT, totalAmb);
   glMaterialfv(GL_FRONT, GL_DIFFUSE, totalDif);
   glMaterialfv(GL_FRONT, GL_SPECULAR, totalSpe);
   glMaterialf(GL_FRONT, GL_SHININESS, totalShi);
   
   glPushMatrix();
   glTranslatef(0.0f,0.0f,0.0f);
   glRotatef(angulo,0.0f,1.0f,0.0f);
   glRotatef(15.0f,1.0f,0.0f,0.0f);
   glutSolidTeapot(3.0f);
   glPopMatrix();

   //Nada
   glMaterialfv(GL_FRONT, GL_AMBIENT, nadaAmb);
   glMaterialfv(GL_FRONT, GL_DIFFUSE, nadaDif);
   glMaterialfv(GL_FRONT, GL_SPECULAR, nadaSpe);
   glMaterialf(GL_FRONT, GL_SHININESS, nadaShi);
   
   glPushMatrix();
   glTranslatef(0.0f,-10.0f,0.0f);
   glRotatef(angulo,0.0f,1.0f,0.0f);
   glRotatef(15.0f,1.0f,0.0f,0.0f);
   glutSolidTeapot(3.0f);
   glPopMatrix();

   //Solo Difusion
   glMaterialfv(GL_FRONT, GL_AMBIENT, difusionAmb);
   glMaterialfv(GL_FRONT, GL_DIFFUSE, difusionDif);
   glMaterialfv(GL_FRONT, GL_SPECULAR, difusionSpe);
   glMaterialf(GL_FRONT, GL_SHININESS, difusionShi);
   
   glPushMatrix();
   glTranslatef(10.0f,10.0f,0.0f);
   glRotatef(angulo,0.0f,1.0f,0.0f);
   glRotatef(15.0f,1.0f,0.0f,0.0f);
   glutSolidTeapot(3.0f);
   glPopMatrix();

   //Solo Ambiente
   glMaterialfv(GL_FRONT, GL_AMBIENT, ambienteAmb);
   glMaterialfv(GL_FRONT, GL_DIFFUSE, ambienteDif);
   glMaterialfv(GL_FRONT, GL_SPECULAR, ambienteSpe);
   glMaterialf(GL_FRONT, GL_SHININESS, ambienteShi);
   
   glPushMatrix();
   glTranslatef(10.0f,0.0f,0.0f);
   glRotatef(angulo,0.0f,1.0f,0.0f);
   glRotatef(15.0f,1.0f,0.0f,0.0f);
   glutSolidTeapot(3.0f);
   glPopMatrix();

   //Solo Especular
   glMaterialfv(GL_FRONT, GL_AMBIENT, especularAmb);
   glMaterialfv(GL_FRONT, GL_DIFFUSE, especularDif);
   glMaterialfv(GL_FRONT, GL_SPECULAR, especularSpe);
   glMaterialf(GL_FRONT, GL_SHININESS, especularShi);
   
   glPushMatrix();
   glTranslatef(10.0f,-10.0f,0.0f);
   glRotatef(angulo,0.0f,1.0f,0.0f);
   glRotatef(15.0f,1.0f,0.0f,0.0f);
   glutSolidTeapot(3.0f);
   glPopMatrix();

   glutSwapBuffers();                    //Se hace el cambio de buffer
}


void Redimensionar(GLsizei ancho, GLsizei alto)
{
	if(alto == 0)
	{
	  alto = 1;
	}
 
	glViewport(0, 0, ancho, alto);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	if(ancho>alto)
	{
		gluPerspective(45.0f,ancho/alto,1,150.0f);
	}
	else
	{
		gluPerspective(45.0f,alto/ancho,1,150.0f);
	}
 	
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void InicializarGL(void)
{
	glClearColor(0.5f,0.5f,0.5f,1.0f);

	//Parametros de la luz 0
	GLfloat ambientlight[] =	{0.5f ,0.5f ,0.5f ,1.0f};
	GLfloat difuselight[] =		{1.0f ,1.0f ,1.0f ,1.0f};
	GLfloat specularlight[] =	{1.0f ,1.0f ,1.0f ,1.0f};
	GLfloat lightposition[] =	{20.0f,100.0f,10.0f,0.0f};
	
	//Se setean los parametros
	glLightfv(GL_LIGHT0,GL_AMBIENT,ambientlight);
	glLightfv(GL_LIGHT0,GL_DIFFUSE,difuselight);
	glLightfv(GL_LIGHT0,GL_SPECULAR,specularlight);
	glLightfv(GL_LIGHT0,GL_POSITION,lightposition);

	glEnable(GL_DEPTH_TEST);	//Test de profundidad
	glEnable(GL_LIGHTING);	    //se activa la iluminacion
	glEnable(GL_LIGHT0);	    //se activa la luz 0 que previamente se habia seteado
	
	glEnable(GL_COLOR_MATERIAL);	//Se activa lo materiales de color
	glColorMaterial(GL_BACK,GL_AMBIENT_AND_DIFFUSE);  //Se desean de tipo ambiente y difusi�n (tambien incluyen specular
	
}

void animacionGL(void)
{
	angulo+=0.2f; 
	glutPostRedisplay();
}

void main(void)
{
	glutInitWindowPosition(120,120);
	glutInitWindowSize(800,800);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB); //En este punto se hace la solicitud de doble buffer
	
	glutCreateWindow("Superficies en OpenGL");
	InicializarGL();
	glutIdleFunc(animacionGL);
	glutDisplayFunc(render);
    glutReshapeFunc(Redimensionar);
    glutMainLoop();
}

